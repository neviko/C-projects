#include <stdio.h>
#include <stdlib.h>
#include "slist.h"

//init the list - init the pointers the head and the tail and make size to be zero.
void slist_init(slist_t *list)
{
	if(list==NULL)
	{
		return;
	}
		

	slist_head(list) = NULL;
	slist_tail(list) = NULL;
	slist_size(list) = 0;
}

//destroy the list -> if it allocated than we have to free the data, anyway,free the nodes and the list.
void slist_destroy(slist_t *list,slist_destroy_t list_des)
{

	if(list==NULL)
	{
		return;
	}	

	if(slist_size(list)==0)
	{
		return;
	}

	void *temp;

	while(slist_size(list)!=0)
	{
		temp=slist_pop_first(list);

		if(list_des == SLIST_FREE_DATA)
		{
			
			free(temp);
		}		
		
	}
	
	
	
}

void *slist_pop_first(slist_t *list)
{
	
	void* value;

	if(slist_head(list)==NULL)
	{
		return NULL;
	}

	slist_node_t *pop_node = slist_head(list);
	value = (void*)slist_data(slist_head(list));
	slist_head(list) = slist_next(slist_head(list));

	if(slist_size(list)>0)
	{
		slist_size(list)-=1;
	}

	if(slist_size(list)==0)
	{
		slist_head(list)==NULL;
		slist_tail(list)==NULL;
	}

	free(pop_node);

	return value;
}


int slist_append(slist_t *list,void *data)
{

	slist_node_t *newNode = (slist_node_t*)malloc(sizeof(slist_node_t));
	if(newNode==NULL)
	{
		return -1;
	}

	slist_data(newNode) = data;

	if(slist_head(list)==NULL)
	{
		slist_head(list) = newNode;
		slist_tail(list) = newNode;
	}
	else
	{
		slist_node_t *temp;
		temp = slist_tail(list);
		slist_tail(list) = newNode;
		slist_next(temp) = slist_tail(list);
	}
	
	
	slist_next(newNode) = NULL;
	slist_size(list)+=1;
	return 0;

}



int slist_prepend(slist_t *list,void *data)
{
	slist_node_t *newNode = (slist_node_t*)malloc(sizeof(slist_node_t));
	if(newNode==NULL)
	{
		printf("malloc of newNode didnt succsed\n");
		return -1;
	}
	slist_data(newNode) = data;

	//first we will check if the list is empty : 
	if(slist_head(list)==NULL)
	{
		slist_head(list) = newNode;
		slist_tail(list) = newNode;
		slist_next(newNode)= NULL;
	}
	else
	{
		slist_next(newNode) = slist_head(list);
		slist_head(list) = newNode;
	}
	slist_size(list)+=1;
	return 0;
}

//what found in B move to the first of A- B is still there !
int slist_append_list(slist_t* listA, slist_t* listB)
{
	int x = 0;
	 slist_node_t* temp;
	 temp = slist_head(listB);
	if(slist_head(listB)!=NULL)
	{
		while(temp!=NULL)
		{		
			 x = slist_append(listA,slist_data(temp));
			temp = slist_next(temp);
		}

		return x;

	}

	else if(slist_head(listB)==NULL)
	{
	
		return 0;
	}

}



