

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pattern_matching.h"

void createNewState(pm_state_t*,int,int);
void rec_destroy(pm_state_t*);
void printOutPutList(pm_state_t*);
int count_Words(int,char*);

int pm_init(pm_t* fsm)
{
	if(fsm==NULL)
	{
		return -1;
	}

	//the start of the new fsm is being 0. 

	fsm->newstate=0;
	//malloc the lists of the transtition and the out put
	//malloc the state -> all his elements
	pm_state_t* newState =(pm_state_t*)malloc(sizeof(pm_state_t));
	if(newState==NULL)
	{
		exit(-1);
	}
		//now we will create the first state of the root.
	createNewState(newState,fsm->newstate,0);
	
	newState->output=NULL;
	newState->fail=NULL;

	fsm->zerostate = newState;
	fsm->newstate++;
	return 0;
}

pm_state_t* pm_goto_get(pm_state_t *state,unsigned char symbol)
{
	//if the state is NULL
	if(state==NULL)
	{
		return NULL;
	}


	slist_node_t *listNode;
	if(state->_transitions==NULL)
	{
		return NULL;
	}

	listNode = slist_head(state->_transitions);
	//all the transitions are the edges from a state.

	//check if we can find the word at the connaction.
	while(listNode!=NULL)
	{
		//we need to do casting because data is void* 
		//and it can be everything including struct !

		if(((pm_labeled_edge_t*)slist_data(listNode))->label==symbol)
		{
			//return the next state !
			return ((pm_labeled_edge_t*)slist_data(listNode))->state; // we found the word. return the state.
		}

		listNode = slist_next(listNode);

		//now i want to return the next state !!
		// from the struct pm_laabled_edge_t
	}

//if i didnt find the word at the list of the transtion
	//I will return NULL
	return NULL;

}


int pm_goto_set(pm_state_t *from_state,unsigned char symbol,pm_state_t *to_state)
{


	//if the state are NULL return -1 -> failed.
	if(from_state==NULL||to_state==NULL)
	{
		return -1;
	}
//allocate edge 
	pm_labeled_edge_t* newEdge = (pm_labeled_edge_t*)malloc(sizeof(pm_labeled_edge_t));
	if(newEdge==NULL)
	{
		exit(-1);
	}
	to_state->depth += from_state->depth;
	newEdge->label = symbol;
	newEdge->state = to_state;

	printf("%d -> %c -> %d\n ",from_state->id,symbol,to_state->id);

	if(from_state->_transitions==NULL)
	{
		//if the list of the from_state -> transition is NULL -> allocate it.
		slist_t* newTransition = (slist_t*)malloc(sizeof(slist_t));
		if(newTransition==NULL)
		{
			exit(-1);
		}
		from_state->_transitions = newTransition;
	}	

	int check= slist_append(from_state->_transitions,newEdge);
	if(check==-1)
	{
		//if it NULL free the newEdge
		return -1;
	}


return 0;

}


int pm_addstring(pm_t *fsm,unsigned char *word, size_t n)
{
	

	if(fsm==NULL)
	{
		printf("fsm is NULL\n");
		return -1;
	}

	int counter;
	counter = count_Words(counter,word);

	if(word==NULL||strcmp(word,"")==0||counter==0)
	{
		printf("word==NULL|| word number is 0 or word is space\n");
		return -1;
	}

	//to send to the create new state when needed by the set.
	pm_state_t* aNewState;
	//to point the root
	pm_state_t* PointertoState;
	PointertoState = fsm->zerostate;
	int i=0;
	
	
	while(i<n)
	{
		if(pm_goto_get(PointertoState,word[i])!=NULL)
		{
			PointertoState = pm_goto_get(PointertoState,word[i]);
		}

		else
		{
			
			//create new state
			pm_state_t* aNewState = (pm_state_t*)malloc(sizeof(pm_state_t)); 
			if(aNewState==NULL)
			{
				printf("MALLOC in line 186 FAILD\n");
				exit(-1);
			}
			createNewState(aNewState,fsm->newstate,PointertoState->depth++);
			
			int check = pm_goto_set(PointertoState,word[i],aNewState);
			if(check==-1)
			{
				return -1;
			}
			fsm->newstate++;
			PointertoState = aNewState;
		}
		i++;
	
			
	}	

	int q = slist_append(PointertoState->output, word);

	if(q==-1)
	{
		return -1;
	}

	return 0;


}


//now we will make all the failers.
int pm_makeFSM(pm_t *fsm) 
{
	//check if the fsm is NULL  
	if(fsm==NULL)
	{
		printf("fsm not allocated\n");
		return -1;
	}
//allocate List that will be used as queue.

	slist_t* queue = (slist_t*)malloc(sizeof(slist_t));
	
	if(queue==NULL)
	{
		printf("MALLOC in line 240 FAILD\n");
		exit(-1);	
	}

	slist_init(queue);
	//pointers declerations.
	slist_node_t* pState;
	pm_state_t* popState;
	pm_state_t* Nextstate;
	pm_labeled_edge_t* connaction;
	pm_state_t* ptr;
	pm_state_t* failureState;
	//////////////////////
	int check;
	//Pstate (node) is now the head of the zero state _transtion.
	pState = slist_head(fsm->zerostate->_transitions); 

	//first we will add all the sons of the root to the qeueue and make theres failure to the root. 
	while(pState!= NULL)
	{
		//nextstate(state)
		Nextstate = ((pm_labeled_edge_t*)slist_data(pState))->state;
		check = slist_append(queue, Nextstate);
		if(check==-1)
		{
			return -1;
		}
		Nextstate->fail = fsm->zerostate;
		pState = slist_next(pState);
	}
//check the qeue list -> if it not empty ,pop the sons of the root.
	while(slist_size(queue)>0) 
	{
		popState = slist_pop_first(queue);
		//point with Pstate to the _trantion of the son's root.
		pState = slist_head(popState->_transitions);
		//go over the sons _trantion and enter to the qeueu theres sons.
		while(pState!=NULL) 
		{
			//connaction(egde) , ptr(state)
			connaction = ((pm_labeled_edge_t*)slist_data(pState));
			ptr = connaction->state;
			check = slist_append(queue, ptr);
			if(check==-1)
			{
				return -1;
			}
			//stater will be the failure of the father.
			pm_state_t* stater = popState->fail;
			//try to go on the tree, with get func and search if can get the state from the failure.
			failureState = pm_goto_get(stater, connaction->label);
			int flag =0;
//////////////while there is no way to go, go to the father failure//////////////////
			while(failureState==NULL)
			{
				if(stater->id==0)
				{
					flag=1;
					break;
				}
				stater = stater->fail;
				failureState = pm_goto_get(stater, connaction->label);
			}
			if(flag==1)
			{
				ptr->fail = stater;
				printf("Settings f(%d) = %d\n", ptr->id, ptr->fail->id);


			}

			else
			{
				ptr->fail = failureState;
				printf("Settings f(%d) = %d\n", ptr->id, ptr->fail->id);
			//add the fail output to the output list.
				check = slist_append_list(ptr->output, ptr->fail->output);
				if(check==-1)
				{
					return -1;
				}

			}

			pState = slist_next(pState);
		}
	}
	//destroy the qeueue.
	slist_destroy(queue,0);
	//free queue.
	free(queue);
	return 0;
}



slist_t* pm_fsm_search(pm_state_t* state,unsigned char* word,size_t size)
{

//check if the state we got is not NULL
	if(state ==NULL)
	{
		printf("state is NULL\n");
		return NULL;
	}

//create list that will have inside **************/////////////////////////////
	slist_t* matched_list = (slist_t*)malloc(sizeof(slist_t));
	if(matched_list==NULL)
	{
		printf("MALLOC in line 355 FAILD\n");
		exit(-1);
	} 
	slist_init(matched_list);
	int check;
	int i;

	for(i=0;i<size;i++)
	{
		//check the state failure and if we cannot procced go to the failure state.
		while(state->fail!=NULL&&pm_goto_get(state,word[i])==NULL)
		{
			
			state = state->fail;

		}

		//if we found a way that we can go with the label to another state.
		if(pm_goto_get(state,word[i])!=NULL)
		{
			state = pm_goto_get(state,word[i]);
		}


		int j =0;
		char* tempChar;
		//check if the state is accepted state and have labels on his list.
		if(state->output!=NULL&&slist_size(state->output)>0)
		{
			slist_node_t* outPoint = slist_head(state->output);

			while(j<slist_size(state->output))
			{
				tempChar = slist_data(outPoint);
				pm_match_t* pm_match = (pm_match_t*)malloc(sizeof(pm_match_t));
				if(pm_match==NULL)
				{
					printf("MALLOC in line 396 FAILD\n");
					exit(-1);
				}

				if(outPoint!=NULL)
				{
					pm_match->start_pos=i-strlen((char*)outPoint->data)+1;
					pm_match->end_pos=i;
					pm_match->fstate=state;			
					pm_match->pattern=(unsigned char*)outPoint->data;
					check = slist_append(matched_list,pm_match);
					printf("pattern : %s , statrs at : %d , ends at : %d , last state : %d\n",pm_match->pattern ,pm_match->start_pos,pm_match->end_pos,state->id );

				}

				j++;
				outPoint = slist_next(outPoint);

			}

		}
	}

	return matched_list;


}



void pm_destroy(pm_t* pm)
{
	rec_destroy(pm->zerostate);
}

void rec_destroy(pm_state_t* state)
{
	slist_node_t* p = slist_head(state->_transitions);
	while(p!=NULL)
	{
		pm_state_t* newState = ((pm_labeled_edge_t*)slist_data(p))->state;
		rec_destroy(newState);
		p=slist_next(p);

	}

	slist_destroy(state->output,SLIST_LEAVE_DATA);
	slist_destroy(state->_transitions,SLIST_FREE_DATA);
	if(state->output!=NULL)
	{
			free(state->output);
	}
	free(state->_transitions);
	free(state);
}



void createNewState(pm_state_t* state ,int id,int depth)
{
	if(state ==NULL)
	{
		exit(1);
	}
	if(id!=0)
	{
		slist_t* outputList=(slist_t*)malloc(sizeof(slist_t));

		if(outputList ==NULL)
		{
			printf("MALLOC in line 473 FAILD\n");
			exit(-1);
		}
		slist_init(outputList);
		state->output = outputList;
	}


	slist_t* list_tr=(slist_t*)malloc(sizeof(slist_t));

	if(list_tr ==NULL)
	{
		printf("MALLOC in line 485 FAILD\n");
		exit(-1);
	}

	slist_init(list_tr);
	state->_transitions = list_tr;	


	state->id = id;
	state->depth = depth;
	


	printf("allocating state : %d\n",id );
}


void printOutPutList(pm_state_t* state)
{
	//print the OUTPUT LIST of a state : 

	
	slist_node_t* t;
	t= slist_head(state->output);
	while(t!=NULL)
	{
		printf("state id is [%d] , output list is : [%s]\n",state->id,(char*)slist_data(t));
		t=slist_next(t);

	}
}

int count_Words(int counter,char* word)
{
	counter =0;
	int i;
	for(i=0;word[i]!='\0';i++)
	{
		if(word[i]==' '|| word[i]=='\t')
		{
			continue;
		}

		counter++;
		

	}
	return counter;
}