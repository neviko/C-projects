

//******************************************************************
//							nevo sayag
//							200484426

//******************************************************************

#include <stdio.h>
#include <unistd.h> 
#include <stdlib.h> 
#include "slist.h"

void print(slist_t*);



void slist_init(slist_t * list)
{
	if(list==NULL) 
	{
		printf("list where not allocated\n");
		return;
	}

	slist_head(list)=NULL;
	slist_tail(list)=NULL;
	slist_size(list)=0;

}

// check if the enum flag is on, if it is so deallocate memory.
// isAllocated is an enum type.
void slist_destroy(slist_t* list ,slist_destroy_t isAllocated)
{

	if(list == NULL)
		return;

	void* temp;
	while(slist_size(list) != 0)
	{
		temp=slist_pop_first(list);
		if(isAllocated == SLIST_FREE_DATA)
		{
			free(temp);
		}
	}
	
}

void* slist_pop_first(slist_t* list)
{
	if(list==NULL)
		return NULL;

	if(slist_head(list)==NULL)
		return NULL;

	void* tempValue = (void*) slist_data(slist_head(list));// save the value of the head in temp
	void* tempPtr =slist_head(list);

	if(slist_head(list) != slist_tail(list))
		slist_head(list)= slist_next(slist_head(list)); // increase the head
	

	else
		slist_head(list)=NULL;	
				
	free(tempPtr);
	slist_size(list)--;
	
	return tempValue;
}


int slist_append(slist_t *list ,void *data)
{	
	//dynamic allocation for the new node
	slist_node_t* newNode =(slist_node_t*)malloc(sizeof(slist_node_t));
	if(newNode==NULL)
		return -1;

	//set the new node fildes
	slist_data(newNode)=data;
	slist_next(newNode)=NULL;

	if(slist_size(list) == 0)// if is an empty list set the head and the tail.
	{
		slist_head(list)=newNode;
		slist_tail(list)=newNode;
		slist_size(list)++;
		return 0;
	}

	// change the last node "next" field to be to the new node 
	slist_next(slist_tail(list)) = newNode;
	slist_tail(list)=newNode;// set the new tail
	slist_size(list)++;
	return 0;
}

// private method
void print(slist_t* list)
{
	if(list==NULL)
	{
		printf("list is null\n");
		return;
	}

	printf("TEST\n");

   slist_node_t* p= list->head;
   int i=0;
   if(slist_size(list) == 0)
   {
		printf("THE LIST IS NULL\n");
		return;
   } 
   printf("-->");
   
   while(p!=NULL)// run until equals to size 
   {
		printf("||%d ~ %p || --> ",i,(void*)p->data);
	  	p=p->next;
		i++;
   }
	printf("\n");
}


int slist_prepend(slist_t *list,void *data)
{
	//dynamic allocation for the new node
	slist_node_t* newNode =(slist_node_t*)malloc(sizeof(slist_node_t));
	if(newNode==NULL)
		return -1;

	//set the new node fildes
	slist_data(newNode)=data;
	slist_next(newNode)=NULL;

	if(slist_size(list) == 0)// if is an empty list set the head and the tail.
	{
		slist_head(list)=newNode;
		slist_tail(list)=newNode;
		slist_size(list)++;
		return 0;
	}

	slist_next(newNode)=slist_head(list);
	slist_head(list)=newNode;
	slist_size(list)++;

}

int slist_append_list(slist_t* listA, slist_t* listB)
{
	
	if(listA == NULL || listB == NULL)
	{
		printf("one of the lists is null\n");
		return -1;
	}


	if(slist_size(listB) == 0)//adding an empty list
	{
		return 0;
	}


	slist_node_t* ptr = slist_head(listB);
	while(ptr != NULL)
	{
		slist_append(listA,slist_data(slist_head(listB) )  );
		ptr=slist_next(ptr);
	} 


	//we don't need to deallocate listB becouse she is not allocated !!!!!!
}

